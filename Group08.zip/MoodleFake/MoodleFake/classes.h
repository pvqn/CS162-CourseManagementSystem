#pragma once
#include "struct.h"
using namespace std;

void createClass(Class*& classes);

