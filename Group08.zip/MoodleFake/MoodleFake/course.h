﻿#pragma once
#include "struct.h"

using namespace std;


void addCourse(Course*& pCourse);
void view_Course(Course* pCur);
void updateCourse(Course*& pCur);

void DeleteCourse(Course*& pCourse);
Course* add();

