#pragma once
#include <Windows.h>
void gotoxy(short x, short y);
void cls(HANDLE hConsole);

