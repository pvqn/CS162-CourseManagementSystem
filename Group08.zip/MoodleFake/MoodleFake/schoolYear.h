#pragma once
#include <direct.h>
#include "struct.h"
using namespace std;
void setCurrentYear(int year);
int getCurrentYear();

