#pragma once
#include <iostream>
#include <string>

void viewScoreboard();
bool studentChoice(int& choice, User*& acc, string& username, string& password, Class*& classes, Student* student); // Cac lua chon menu cua hoc sinh



